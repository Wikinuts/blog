import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Posts';

  posts = [
    {
      title : 'Mon premier post',
      content : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nisl nulla, tincidunt eu sapien in, euismod commodo libero. Sed ut quam augue. Sed in dignissim ligula.',
      loveIts : 0,
      created_at: new Date()
    },
    {
      title : 'Mon second post',
      content : 'Duis semper luctus ligula, et lobortis nisl faucibus quis. Nam ornare ex vitae ex scelerisque aliquam. Pellentesque at mi ligula. Maecenas vel diam magna.',
      loveIts : 0,
      created_at: new Date()
    },
    {
      title : 'Encore un post',
      content : 'Sed eu condimentum nisi, eu fringilla magna. Sed congue turpis id lacus mollis semper. Duis sagittis erat erat, vel finibus sapien condimentum ut.',
      loveIts : 0,
      created_at: new Date()
    }
  ];

}
